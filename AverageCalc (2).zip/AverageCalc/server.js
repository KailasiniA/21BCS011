const mongoose = require('mongoose')
const port = 9876
const express = require('express')
const Calculator = require('./models/calculator.model')
const app = express()
mongoose.connect('mongodb://localhost:27017/calculator')
.then(()=>{
  console.log("Connected to database..")
})
.catch((error)=>{
  console.log(error)
})
app.listen(port,()=>{
  console.log("Server listening at port no 9876...")
})
class Queue
{
  constructor(size){
    this.windowSize = size
    this.array = []
    this.prev =[]
    this.current =[]
  }
  isempty(){
    return this.array.length==0
  }
  dequeue(){
    if(!this.isempty())
      this.array.pop(0)
  }
  enqueue(item){
    this.array.push(item)
    this.current.push(item)
    if(this.array.length==this.windowSize)
    {
      this.current.push(item)
    }
    else
    {
      while(this.current.length!=10)
        this.current.pop(0)
    }
  }
  avg(){
    let aver = 0.0
    let sum=0
    for(let i=0;i<this.windowSize;i++)
    {
      sum+=this.current[i]
    }
    aver = sum/this.windowSize
    return aver
  }
}
app.post('/number/e',async(req,res)=>{
  const numbers  = req.body
  const q1 = new Queue(10)
  q1.enqueue(numbers)
  const average = q1.avg()
  try{
    const calc = new Calculator({
      numbers: q1.array,
      windowPrevState: q1.prev,
      windowCurrState: q1.current,
      avg: average
    })
    await calc.save()
    res.status(200).send("Saved")
  }catch(error)
  {
    res.status(401).send('error')
  }
})
app.post('/number/p',async(req,res)=>{
  const numbers  = req.body
  const q2 = new Queue(10)
  q2.enqueue(numbers)
  const average = q2.avg()
  try{
    const calc = new Calculator({
      numbers: q2.array,
      windowPrevState: q2.prev,
      windowCurrState: q2.current,
      avg: average
    })
    await calc.save()
    res.status(200).send("Saved")
  }catch(error)
  {
    res.status(401).send('error')
  }
})
app.post('/number/f',async(req,res)=>{
  const numbers  = req.body
  const q3 = new Queue(10)
  q3.enqueue(numbers)
  const average = q3.avg()
  try{
    const calc = new Calculator({
      numbers: q3.array,
      windowPrevState: q3.prev,
      windowCurrState: q3.current,
      avg: average
    })
    await calc.save()
    res.status(200).send("Saved")
  }catch(error)
  {
    res.status(401).send('error')
  }
})
