const mongoose = require('mongoose')
const Calcschema = new mongoose.Schema({
  numbers: Array,
  windowPrevState: Array,
  windowCurrState: Array,
  avg: Number
})
const Calculator = mongoose.model('Calculator',Calcschema)
module.exports = Calculator
